package MVC;

public class SoSLogic {
}
