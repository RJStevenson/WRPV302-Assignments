package models;

import com.wrpv302.a1.contacts.R;

public class ContactItem {
    public String Name;
    public String Number;
    public String Img;

    public ContactItem(String name, String number, String img)
    {
       Name = name;
       Number = number;
       Img = img;
    }
}
